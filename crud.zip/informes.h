#ifndef INFORMES_H
#define INFORMES_H

#include "estructuras.h"

// Funci�n contenedora del men� de listados en texto
void generarInformesTxt();

#endif // INFORMES_H
